# Landing Page Reference — Real HTML Examples

Source: `landing.html` (Context Platform Stack showcase). Copy-paste ready.

## Editorial Contract
One file, zero build. Discovery artifact. 10-second hook.
Has: meta bar, hero + SVG diagram, format cards, stack-at-a-glance, field notes, about, footer.
Never has: prose, code blocks, step-by-step (those live in playbook).

## Document shell
```html
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Paula Silva · Software Global Black Belt</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>/* all CSS inline — tokens + components */</style>
</head>
<body>
  <!-- 1 meta-bar 2 hero 3 formats 4 stack 5 articles 6 about 7 footer -->
  <script>/* theme toggle only */</script>
</body>
</html>
```

## CSS tokens (verbatim)
```css
:root {
  --c-red-50:#FFF0EB;   --c-red-500:#F25022;   --c-red-700:#B33816;
  --c-green-50:#F1F8E3; --c-green-500:#7FBA00; --c-green-700:#5A8500;
  --c-blue-50:#E5F6FD;  --c-blue-500:#00A4EF;  --c-blue-700:#0076AC;
  --c-yellow-50:#FFF7E0;--c-yellow-500:#FFB900;--c-yellow-700:#B88500;
  --ink:#1A1A1A; --ink-2:#3A3A3A; --ink-3:#737373;
  --paper:#FFFFFF; --bg:#F7F7F5; --bg-alt:#ECECE8;
  --rule:#E5E5E0; --rule-2:#CECEC7;
  --font-sans:'Inter',-apple-system,BlinkMacSystemFont,Helvetica,sans-serif;
  --font-mono:'JetBrains Mono',ui-monospace,SFMono-Regular,Menlo,monospace;
  --measure:680px;
}
[data-theme="dark"] {
  --ink:#F0F0F0; --ink-2:#C7C7C2; --ink-3:#A8A8A4;
  --paper:#1C1C1A; --bg:#141414; --bg-alt:#242420;
  --rule:#2E2E2A; --rule-2:#3A3A36;
}
```

## Meta bar (copy verbatim)
```html
<header class="meta-bar">
  <a href="#" class="brand">
    <div class="brand__squares" aria-hidden="true">
      <i class="r"></i><i class="g"></i><i class="b"></i><i class="y"></i>
    </div>
    <div class="brand__text">
      <div class="brand__title">Project Title</div>
      <div class="brand__sub">by Paula Silva</div>
    </div>
  </a>
  <div class="top-tools">
    <a href="#formats" class="top-link">Formats</a>
    <a href="#stack" class="top-link">The stack</a>
    <a href="#about" class="top-link">About</a>
    <button class="tool-btn" id="theme-toggle" title="Toggle theme" aria-label="Toggle theme">
      <svg id="icon-sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display:none;"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></svg>
      <svg id="icon-moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
    </button>
  </div>
</header>
```
```css
.meta-bar{background:var(--paper);border-bottom:1px solid var(--rule-2);padding:16px 32px;display:flex;align-items:center;justify-content:space-between;font-family:var(--font-mono);font-size:13px;letter-spacing:0.08em;color:var(--ink-3);position:sticky;top:0;z-index:100;backdrop-filter:blur(8px);}
.brand{display:flex;align-items:center;gap:14px;text-decoration:none;color:inherit;}
.brand__squares{display:grid;grid-template-columns:14px 14px;grid-template-rows:14px 14px;gap:2px;}
.brand__squares i{display:block;}
.brand__squares .r{background:var(--c-red-500);}
.brand__squares .g{background:var(--c-green-500);}
.brand__squares .b{background:var(--c-blue-500);}
.brand__squares .y{background:var(--c-yellow-500);}
.brand__title{color:var(--ink);font-weight:600;font-size:14px;font-family:var(--font-sans);}
.brand__sub{font-size:11px;letter-spacing:0.12em;}
.top-link{padding:6px 12px;text-decoration:none;color:var(--ink-2);font-family:var(--font-mono);font-size:12px;letter-spacing:0.08em;border-radius:4px;transition:background 0.15s,color 0.15s;}
.top-link:hover{background:var(--bg-alt);color:var(--ink);}
.tool-btn{width:38px;height:38px;border:1px solid var(--rule-2);background:var(--paper);border-radius:6px;color:var(--ink-2);cursor:pointer;display:inline-flex;align-items:center;justify-content:center;}
.tool-btn svg{width:16px;height:16px;}
```

## Hero (copy verbatim)
```html
<section class="hero">
  <div class="hero__grid container">
    <div>
      <div class="hero__eyebrow"><span class="dot"></span>A framework for AI-native systems</div>
      <h1 class="hero__title">Four layers of engineering discipline to prevent the agent cemetery.</h1>
      <p class="hero__subtitle">Why pilots work in the lab and die in production, and the smallest set of patterns that prevents it.</p>
      <div class="hero__cta">
        <a href="playbook/" class="btn btn--primary">Read the playbook <svg viewBox="0 0 24 24"><path d="M5 12h14M13 5l7 7-7 7"/></svg></a>
        <a href="#formats" class="btn btn--ghost">See all formats</a>
      </div>
    </div>
    <div class="hero__art">
      <svg viewBox="0 0 500 380" role="img">
        <!-- Layer 4: Intent (red) -->
        <rect x="20" y="20" width="460" height="70" rx="8" fill="var(--c-red-50)" stroke="var(--c-red-500)" stroke-width="0.6"/>
        <rect x="20" y="20" width="5" height="70" fill="var(--c-red-500)"/>
        <text x="44" y="46" font-family="JetBrains Mono,monospace" font-size="10" font-weight="500" letter-spacing="0.14em" fill="var(--c-red-700)">LAYER 04 · INTENT</text>
        <text x="44" y="68" font-family="Inter,sans-serif" font-size="14" font-weight="500" fill="var(--c-red-700)">What should the agent optimize for?</text>
        <line x1="240" y1="98" x2="240" y2="118" stroke="var(--ink-3)" stroke-width="1.2"/>
        <polygon points="236,120 244,120 240,126" fill="var(--ink-3)"/>
        <!-- Layer 3: Context (yellow) -->
        <rect x="20" y="132" width="460" height="70" rx="8" fill="var(--c-yellow-50)" stroke="var(--c-yellow-500)" stroke-width="0.6"/>
        <rect x="20" y="132" width="5" height="70" fill="var(--c-yellow-500)"/>
        <text x="44" y="158" font-family="JetBrains Mono,monospace" font-size="10" font-weight="500" letter-spacing="0.14em" fill="var(--c-yellow-700)">LAYER 03 · CONTEXT</text>
        <text x="44" y="180" font-family="Inter,sans-serif" font-size="14" font-weight="500" fill="var(--c-yellow-700)">What can the agent know?</text>
        <line x1="240" y1="210" x2="240" y2="230" stroke="var(--ink-3)" stroke-width="1.2"/>
        <polygon points="236,232 244,232 240,238" fill="var(--ink-3)"/>
        <!-- Layer 2: Platform (green) -->
        <rect x="20" y="244" width="460" height="70" rx="8" fill="var(--c-green-50)" stroke="var(--c-green-500)" stroke-width="0.6"/>
        <rect x="20" y="244" width="5" height="70" fill="var(--c-green-500)"/>
        <text x="44" y="270" font-family="JetBrains Mono,monospace" font-size="10" font-weight="500" letter-spacing="0.14em" fill="var(--c-green-700)">LAYER 02 · PLATFORM</text>
        <text x="44" y="292" font-family="Inter,sans-serif" font-size="14" font-weight="500" fill="var(--c-green-700)">What can agents do, who governs them?</text>
        <!-- Layer 1: Infra (blue, dashed) -->
        <rect x="20" y="324" width="460" height="40" rx="8" fill="var(--c-blue-50)" stroke="var(--c-blue-500)" stroke-width="0.5" stroke-dasharray="4 3"/>
        <text x="44" y="349" font-family="JetBrains Mono,monospace" font-size="10" font-weight="500" letter-spacing="0.14em" fill="var(--c-blue-700)">LAYER 01 · CLOUD &amp; INFRASTRUCTURE</text>
      </svg>
    </div>
  </div>
</section>
```
```css
.hero{padding:96px 0 88px;background:var(--paper);border-bottom:1px solid var(--rule-2);}
.hero__grid{display:grid;grid-template-columns:minmax(0,1.35fr) minmax(0,1fr);gap:80px;align-items:start;max-width:1200px;margin:0 auto;}
.hero__eyebrow{font-family:var(--font-mono);font-size:12px;letter-spacing:0.14em;text-transform:uppercase;color:var(--c-blue-700);font-weight:500;display:inline-flex;align-items:center;gap:10px;margin-bottom:24px;}
.hero__eyebrow .dot{width:6px;height:6px;background:var(--c-blue-500);border-radius:50%;}
.hero__title{font-size:clamp(40px,5vw,60px);font-weight:500;letter-spacing:-0.025em;line-height:1.02;margin:0 0 24px;text-wrap:balance;}
.hero__subtitle{font-size:20px;line-height:1.5;color:var(--ink-2);margin:0 0 36px;max-width:620px;}
.hero__cta{display:flex;gap:14px;flex-wrap:wrap;}
.btn{display:inline-flex;align-items:center;gap:10px;padding:14px 24px;border-radius:6px;font-family:var(--font-sans);font-size:15px;font-weight:500;text-decoration:none;border:1px solid transparent;transition:all 0.15s;}
.btn svg{width:14px;height:14px;stroke:currentColor;stroke-width:2;fill:none;transition:transform 0.2s;}
.btn:hover svg{transform:translateX(3px);}
.btn--primary{background:var(--ink);color:#fff;}
.btn--primary:hover{transform:translateY(-1px);}
.btn--ghost{background:transparent;color:var(--ink);border-color:var(--rule-2);}
.btn--ghost:hover{background:var(--bg-alt);}
```

## Format cards (copy verbatim)
```html
<section class="section" id="formats">
  <div class="container">
    <div class="section__header">
      <div class="section__label">Read it, present it, build with it</div>
      <h2 class="section__title">Four formats, one framework.</h2>
      <p class="section__lead">The same four-layer model, adapted to how you need to engage with it.</p>
    </div>
    <div class="formats">
      <!-- Featured card -->
      <a href="playbook/" class="format-card format-card--featured" data-accent="blue">
        <div class="format-card__accent"></div>
        <div class="format-card__body">
          <span class="format-card__kicker">Playbook · v1.2.0</span>
          <h3 class="format-card__title">The Context Platform Stack</h3>
          <p class="format-card__desc">Six chapters, fully annotated. The complete framework.</p>
          <div class="format-card__meta">
            <span>HTML · ~16,000 words · ~90 min read</span>
            <span class="format-card__arrow"><svg viewBox="0 0 24 24"><path d="M5 12h14M13 5l7 7-7 7"/></svg></span>
          </div>
        </div>
        <div class="format-card__art"><!-- mini SVG preview --></div>
      </a>
      <!-- Standard cards -->
      <a href="deck/" class="format-card" data-accent="green">
        <div class="format-card__accent"></div>
        <div class="format-card__body">
          <span class="format-card__kicker">Deck · 19 slides</span>
          <h3 class="format-card__title">AI Maturity Assessment</h3>
          <p class="format-card__desc">60 to 90 minute presentation. PT, EN and ES built in.</p>
          <div class="format-card__meta"><span>HTML · keyboard-navigable</span><span class="format-card__arrow"><svg viewBox="0 0 24 24"><path d="M5 12h14M13 5l7 7-7 7"/></svg></span></div>
        </div>
      </a>
      <a href="diagrams/" class="format-card" data-accent="yellow"><!-- ... --></a>
      <a href="#articles" class="format-card" data-accent="red"><!-- ... --></a>
    </div>
  </div>
</section>
```
```css
.section{padding:80px 0;border-bottom:1px solid var(--rule);}
.section__label{font-family:var(--font-mono);font-size:11px;letter-spacing:0.14em;text-transform:uppercase;color:var(--ink-3);font-weight:500;margin-bottom:10px;}
.section__title{font-size:clamp(30px,3.2vw,42px);font-weight:500;letter-spacing:-0.02em;line-height:1.1;margin:0 0 16px;text-wrap:balance;}
.section__lead{font-size:18px;line-height:1.55;color:var(--ink-2);max-width:var(--measure);}
.section__header{margin-bottom:48px;}
.container{max-width:1200px;margin:0 auto;padding:0 48px;}
.formats{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:20px;}
.format-card{display:flex;flex-direction:column;background:var(--paper);border:1px solid var(--rule);border-radius:10px;text-decoration:none;color:inherit;overflow:hidden;transition:transform 0.2s,border-color 0.2s,box-shadow 0.25s;}
.format-card:hover{transform:translateY(-3px);border-color:var(--card-accent,var(--rule-2));box-shadow:0 10px 24px rgba(0,0,0,0.05);}
.format-card__accent{height:4px;background:var(--card-accent,var(--ink-3));}
.format-card__body{padding:28px 28px 24px;display:flex;flex-direction:column;flex:1;}
.format-card__kicker{font-family:var(--font-mono);font-size:11px;letter-spacing:0.14em;text-transform:uppercase;color:var(--card-accent);font-weight:500;margin-bottom:14px;}
.format-card__title{font-size:22px;font-weight:500;letter-spacing:-0.015em;margin:0 0 12px;}
.format-card__desc{font-size:15px;line-height:1.55;color:var(--ink-2);margin:0 0 20px;flex:1;}
.format-card__meta{font-family:var(--font-mono);font-size:11px;color:var(--ink-3);display:flex;justify-content:space-between;padding-top:16px;border-top:1px solid var(--rule);}
.format-card__arrow svg{width:14px;height:14px;stroke:currentColor;stroke-width:2;fill:none;transition:transform 0.2s;}
.format-card:hover .format-card__arrow svg{transform:translateX(4px);}
.format-card--featured{grid-column:1/-1;display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);}
.format-card--featured .format-card__accent{grid-column:1/-1;}
.format-card--featured .format-card__body{padding:40px 44px;justify-content:center;}
.format-card--featured .format-card__title{font-size:30px;}
.format-card--featured .format-card__art{background:var(--c-blue-50);display:flex;align-items:center;justify-content:center;padding:32px;border-left:1px solid var(--rule);}
[data-accent="blue"]  {--card-accent:var(--c-blue-500);}
[data-accent="green"] {--card-accent:var(--c-green-500);}
[data-accent="yellow"]{--card-accent:var(--c-yellow-500);}
[data-accent="red"]   {--card-accent:var(--c-red-500);}
[data-accent="ink"]   {--card-accent:var(--ink);}
```

## Stack at a glance (copy verbatim)
```html
<section class="section" id="stack">
  <div class="container">
    <div class="section__header">
      <div class="section__label">The stack at a glance</div>
      <h2 class="section__title">Each layer serves the one above. Each constrains the one below.</h2>
    </div>
    <div class="stack-overview">
      <div class="stack-layer stack-layer--red">
        <span class="stack-layer__num">04</span>
        <div class="stack-layer__body">
          <div class="stack-layer__name"><span class="stack-layer__name-accent">Intent engineering</span>Constitutions, specifications, governance</div>
          <div class="stack-layer__question">What should the agent optimize for?</div>
        </div>
        <a href="playbook/#/chapter/04" class="stack-layer__link">Chapter 4 <svg viewBox="0 0 24 24"><path d="M5 12h14M13 5l7 7-7 7"/></svg></a>
      </div>
      <div class="stack-layer stack-layer--yellow">
        <span class="stack-layer__num">03</span>
        <div class="stack-layer__body">
          <div class="stack-layer__name"><span class="stack-layer__name-accent">Context engineering</span>ACE, skills, memory tiers, MCP</div>
          <div class="stack-layer__question">What can the agent know?</div>
        </div>
        <a href="playbook/#/chapter/03" class="stack-layer__link">Chapter 3 <svg viewBox="0 0 24 24"><path d="M5 12h14M13 5l7 7-7 7"/></svg></a>
      </div>
      <div class="stack-layer stack-layer--green">
        <span class="stack-layer__num">02</span>
        <div class="stack-layer__body">
          <div class="stack-layer__name"><span class="stack-layer__name-accent">Platform engineering</span>IDP, golden paths, guardrails, RBAC</div>
          <div class="stack-layer__question">What can agents do, and who governs them?</div>
        </div>
        <a href="playbook/#/chapter/02" class="stack-layer__link">Chapter 2 <svg viewBox="0 0 24 24"><path d="M5 12h14M13 5l7 7-7 7"/></svg></a>
      </div>
      <div class="stack-layer stack-layer--blue">
        <span class="stack-layer__num">01</span>
        <div class="stack-layer__body">
          <div class="stack-layer__name"><span class="stack-layer__name-accent">Cloud &amp; infrastructure</span>GPUs, Kubernetes, CNCF services</div>
          <div class="stack-layer__question">Where do agents run, and at what cost?</div>
        </div>
        <a href="playbook/#/chapter/01" class="stack-layer__link">Chapter 1 <svg viewBox="0 0 24 24"><path d="M5 12h14M13 5l7 7-7 7"/></svg></a>
      </div>
    </div>
  </div>
</section>
```
```css
.stack-overview{background:var(--paper);border:1px solid var(--rule);border-radius:10px;padding:36px 40px;}
.stack-layer{display:grid;grid-template-columns:auto 1fr auto;gap:24px;padding:18px 0;border-bottom:1px solid var(--rule);align-items:center;}
.stack-layer:last-child{border-bottom:none;}
.stack-layer__num{width:28px;height:28px;display:inline-flex;align-items:center;justify-content:center;border-radius:4px;font-family:var(--font-mono);font-size:11px;font-weight:600;color:#fff;}
.stack-layer--red    .stack-layer__num{background:var(--c-red-500);}
.stack-layer--yellow .stack-layer__num{background:var(--c-yellow-500);color:var(--ink);}
.stack-layer--green  .stack-layer__num{background:var(--c-green-500);}
.stack-layer--blue   .stack-layer__num{background:var(--c-blue-500);}
.stack-layer__name{font-size:17px;font-weight:500;letter-spacing:-0.01em;}
.stack-layer__name-accent{font-family:var(--font-mono);font-size:11px;letter-spacing:0.12em;text-transform:uppercase;margin-right:10px;}
.stack-layer--red    .stack-layer__name-accent{color:var(--c-red-700);}
.stack-layer--yellow .stack-layer__name-accent{color:var(--c-yellow-700);}
.stack-layer--green  .stack-layer__name-accent{color:var(--c-green-700);}
.stack-layer--blue   .stack-layer__name-accent{color:var(--c-blue-700);}
.stack-layer__question{font-size:14px;color:var(--ink-3);font-style:italic;}
.stack-layer__link{font-family:var(--font-mono);font-size:11px;letter-spacing:0.12em;color:var(--ink-3);text-decoration:none;padding:6px 10px;border-radius:4px;white-space:nowrap;}
.stack-layer__link:hover{background:var(--bg-alt);color:var(--ink);}
.stack-layer__link svg{display:inline-block;width:11px;height:11px;vertical-align:-1px;margin-left:4px;stroke:currentColor;stroke-width:2;fill:none;}
```

## Theme JS (complete, verbatim)
```javascript
(function() {
  const root = document.documentElement;
  const saved = localStorage.getItem('cps-theme');
  if (saved) root.setAttribute('data-theme', saved);
  function updateThemeIcon() {
    const isDark = root.getAttribute('data-theme') === 'dark';
    document.getElementById('icon-sun').style.display  = isDark ? 'block' : 'none';
    document.getElementById('icon-moon').style.display = isDark ? 'none' : 'block';
  }
  updateThemeIcon();
  document.getElementById('theme-toggle').addEventListener('click', () => {
    const next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    root.setAttribute('data-theme', next);
    localStorage.setItem('cps-theme', next);
    updateThemeIcon();
  });
})();
```
