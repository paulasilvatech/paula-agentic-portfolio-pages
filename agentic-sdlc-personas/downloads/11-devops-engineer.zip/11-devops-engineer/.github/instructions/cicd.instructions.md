---
applyTo: ".github/workflows/**,.azure/pipelines/**,Dockerfile,*.dockerfile"
---

# Cicd conventions (DevOps Engineer)

Pipeline conventions: stages, caching, secrets, artifact retention

## Reviewer checklist
- [ ] Naming follows project conventions.
- [ ] Error paths are explicit (no silent failures).
- [ ] Test coverage matches the change scope.
- [ ] No secrets or PII in code or comments.
- [ ] Reference `CONSTITUTION.md` for security-touching changes.
