---
applyTo: "infrastructure/**,*.tf,*.bicep"
---

# Infrastructure conventions (DevOps Engineer)

IaC conventions: modules, tagging, drift detection

## Reviewer checklist
- [ ] Naming follows project conventions.
- [ ] Error paths are explicit (no silent failures).
- [ ] Test coverage matches the change scope.
- [ ] No secrets or PII in code or comments.
- [ ] Reference `CONSTITUTION.md` for security-touching changes.
