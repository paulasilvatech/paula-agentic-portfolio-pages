---
applyTo: "**/copilot-instructions.md,**/.github/**"
---

# Project Setup conventions (Technical Lead)

Project setup conventions and team governance

## Reviewer checklist
- [ ] Naming follows project conventions.
- [ ] Error paths are explicit (no silent failures).
- [ ] Test coverage matches the change scope.
- [ ] No secrets or PII in code or comments.
- [ ] Reference `CONSTITUTION.md` for security-touching changes.
