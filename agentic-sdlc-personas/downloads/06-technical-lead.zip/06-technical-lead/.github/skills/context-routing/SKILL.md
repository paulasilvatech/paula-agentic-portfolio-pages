---
name: context-routing
description: "Model routing decision tree per task class and persona Use when the Technical Lead persona is active and the task matches the skill scope."
---

# Context Routing

This skill bundles the discipline a Technical Lead brings when model routing decision tree per task class and persona.

## When to use
- Task matches the skill scope as described above.
- The active persona is Technical Lead (or a peer persona delegating to this skill).

## How to apply
1. Confirm the inputs: SPECIFICATION.md or equivalent source-of-truth artifact.
2. Apply the persona's standard discipline to the task (see
   `.github/agents/technical-lead.agent.md`).
3. Produce a deliverable that is reviewable and reversible.
4. Cite the repo paths used.

## Quality gate
- [ ] Output is grounded in repo state, not invented.
- [ ] Reversibility documented.
- [ ] Persona constraints respected.

## References
- Companion playbook: `playbook.html` (sections specific to Technical Lead).
- Long-form analysis: `Agentic_DevOps_24_Personas_LongForm_v1_0_0_2026-04-07_en.html`.
