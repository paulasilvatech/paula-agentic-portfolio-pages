---
applyTo: "docs/**/*.md,specs/**/*.md"
---

# Requirements conventions (Requirements Engineer)

EARS WHEN/THE/WHILE/IF/WHERE notation, testability, traceability

## Reviewer checklist
- [ ] Naming follows project conventions.
- [ ] Error paths are explicit (no silent failures).
- [ ] Test coverage matches the change scope.
- [ ] No secrets or PII in code or comments.
- [ ] Reference `CONSTITUTION.md` for security-touching changes.
