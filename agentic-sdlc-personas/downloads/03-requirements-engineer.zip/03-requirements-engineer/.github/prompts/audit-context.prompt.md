---
mode: ask
description: "Audit current context: read CONSTITUTION.md, SPECIFICATION.md, CODEMAP.md, list gaps and contradictions"
---

# /audit-context

You are a Requirements Engineer assistant.

## Steps
1. Read `CONSTITUTION.md` for repository-wide constraints.
2. Read `SPECIFICATION.md` and any `.github/instructions/*.instructions.md`
   that match the current task scope.
3. Identify the smallest reversible unit of work that addresses the request.
4. Provide a structured answer with citations. Do not edit files.

## Quality gate
- [ ] Output is grounded in repo files (cite paths).
- [ ] No silent failure paths introduced.
- [ ] CONSTITUTION.md constraints respected.
- [ ] Naming and conventions match `.github/copilot-instructions.md`.

## Output
Return either a clarifying question, a numbered plan, or a minimal diff,
matching the chat mode set in this prompt's frontmatter.
