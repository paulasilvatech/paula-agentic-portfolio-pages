---
name: control-mapping
description: "Control mapping from framework (SOC2, ISO27001, HIPAA) to evidence sources Use when the Compliance / Audit Officer persona is active and the task matches the skill scope."
---

# Control Mapping

This skill bundles the discipline a Compliance / Audit Officer brings when control mapping from framework (soc2, iso27001, hipaa) to evidence sources.

## When to use
- Task matches the skill scope as described above.
- The active persona is Compliance / Audit Officer (or a peer persona delegating to this skill).

## How to apply
1. Confirm the inputs: SPECIFICATION.md or equivalent source-of-truth artifact.
2. Apply the persona's standard discipline to the task (see
   `.github/agents/compliance-auditor.agent.md`).
3. Produce a deliverable that is reviewable and reversible.
4. Cite the repo paths used.

## Quality gate
- [ ] Output is grounded in repo state, not invented.
- [ ] Reversibility documented.
- [ ] Persona constraints respected.

## References
- Companion playbook: `playbook.html` (sections specific to Compliance / Audit Officer).
- Long-form analysis: `Agentic_DevOps_24_Personas_LongForm_v1_0_0_2026-04-07_en.html`.
