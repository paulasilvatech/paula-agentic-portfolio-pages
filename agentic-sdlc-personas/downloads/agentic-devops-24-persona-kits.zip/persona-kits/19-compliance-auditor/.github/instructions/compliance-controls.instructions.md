---
applyTo: "docs/compliance/**,policies/**"
---

# Compliance Controls conventions (Compliance / Audit Officer)

Control evidence format and audit trail conventions

## Reviewer checklist
- [ ] Naming follows project conventions.
- [ ] Error paths are explicit (no silent failures).
- [ ] Test coverage matches the change scope.
- [ ] No secrets or PII in code or comments.
- [ ] Reference `CONSTITUTION.md` for security-touching changes.
