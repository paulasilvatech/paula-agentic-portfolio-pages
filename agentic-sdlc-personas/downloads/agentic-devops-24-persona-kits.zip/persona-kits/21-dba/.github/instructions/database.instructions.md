---
applyTo: "db/migrations/**,*.sql,**/repositories/**"
---

# Database conventions (DBA / Database Administrator)

Migration conventions: backward-compat, dual-write, rollback path, no destructive ops

## Reviewer checklist
- [ ] Naming follows project conventions.
- [ ] Error paths are explicit (no silent failures).
- [ ] Test coverage matches the change scope.
- [ ] No secrets or PII in code or comments.
- [ ] Reference `CONSTITUTION.md` for security-touching changes.
