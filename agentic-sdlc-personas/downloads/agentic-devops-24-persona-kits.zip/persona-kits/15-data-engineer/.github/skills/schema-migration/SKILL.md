---
name: schema-migration
description: "Backward-compatible schema migration with dual-write strategy Use when the Data Engineer / Analytics Engineer persona is active and the task matches the skill scope."
---

# Schema Migration

This skill bundles the discipline a Data Engineer / Analytics Engineer brings when backward-compatible schema migration with dual-write strategy.

## When to use
- Task matches the skill scope as described above.
- The active persona is Data Engineer / Analytics Engineer (or a peer persona delegating to this skill).

## How to apply
1. Confirm the inputs: SPECIFICATION.md or equivalent source-of-truth artifact.
2. Apply the persona's standard discipline to the task (see
   `.github/agents/data-engineer.agent.md`).
3. Produce a deliverable that is reviewable and reversible.
4. Cite the repo paths used.

## Quality gate
- [ ] Output is grounded in repo state, not invented.
- [ ] Reversibility documented.
- [ ] Persona constraints respected.

## References
- Companion playbook: `playbook.html` (sections specific to Data Engineer / Analytics Engineer).
- Long-form analysis: `Agentic_DevOps_24_Personas_LongForm_v1_0_0_2026-04-07_en.html`.
