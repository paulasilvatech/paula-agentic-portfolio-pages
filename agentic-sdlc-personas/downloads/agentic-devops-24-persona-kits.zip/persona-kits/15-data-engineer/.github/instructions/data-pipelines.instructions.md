---
applyTo: "pipelines/**,dags/**,dbt/**"
---

# Data Pipelines conventions (Data Engineer / Analytics Engineer)

Pipeline conventions: idempotency, schema versioning, data tests

## Reviewer checklist
- [ ] Naming follows project conventions.
- [ ] Error paths are explicit (no silent failures).
- [ ] Test coverage matches the change scope.
- [ ] No secrets or PII in code or comments.
- [ ] Reference `CONSTITUTION.md` for security-touching changes.
