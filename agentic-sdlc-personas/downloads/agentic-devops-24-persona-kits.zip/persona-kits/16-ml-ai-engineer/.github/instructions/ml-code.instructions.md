---
applyTo: "src/ml/**,notebooks/**,*.ipynb"
---

# Ml Code conventions (ML / AI Engineer)

ML conventions: experiment tracking, eval set isolation, model card

## Reviewer checklist
- [ ] Naming follows project conventions.
- [ ] Error paths are explicit (no silent failures).
- [ ] Test coverage matches the change scope.
- [ ] No secrets or PII in code or comments.
- [ ] Reference `CONSTITUTION.md` for security-touching changes.
