---
name: test-strategy
description: "Test strategy generation per spec with risk-based prioritization Use when the QA Engineer / Test Lead persona is active and the task matches the skill scope."
---

# Test Strategy

This skill bundles the discipline a QA Engineer / Test Lead brings when test strategy generation per spec with risk-based prioritization.

## When to use
- Task matches the skill scope as described above.
- The active persona is QA Engineer / Test Lead (or a peer persona delegating to this skill).

## How to apply
1. Confirm the inputs: SPECIFICATION.md or equivalent source-of-truth artifact.
2. Apply the persona's standard discipline to the task (see
   `.github/agents/qa-engineer.agent.md`).
3. Produce a deliverable that is reviewable and reversible.
4. Cite the repo paths used.

## Quality gate
- [ ] Output is grounded in repo state, not invented.
- [ ] Reversibility documented.
- [ ] Persona constraints respected.

## References
- Companion playbook: `playbook.html` (sections specific to QA Engineer / Test Lead).
- Long-form analysis: `Agentic_DevOps_24_Personas_LongForm_v1_0_0_2026-04-07_en.html`.
