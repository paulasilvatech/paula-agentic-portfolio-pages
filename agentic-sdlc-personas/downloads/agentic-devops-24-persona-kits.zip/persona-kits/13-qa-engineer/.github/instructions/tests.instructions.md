---
applyTo: "tests/**,**/*.test.*,**/*.spec.*"
---

# Tests conventions (QA Engineer / Test Lead)

Test conventions: AAA pattern, naming, fixture isolation, no shared state

## Reviewer checklist
- [ ] Naming follows project conventions.
- [ ] Error paths are explicit (no silent failures).
- [ ] Test coverage matches the change scope.
- [ ] No secrets or PII in code or comments.
- [ ] Reference `CONSTITUTION.md` for security-touching changes.
