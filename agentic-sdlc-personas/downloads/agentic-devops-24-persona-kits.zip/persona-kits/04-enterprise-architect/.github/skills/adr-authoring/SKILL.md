---
name: adr-authoring
description: "ADR authoring with Michael Nygard template and reversibility analysis Use when the Enterprise / Solution Architect persona is active and the task matches the skill scope."
---

# Adr Authoring

This skill bundles the discipline a Enterprise / Solution Architect brings when adr authoring with michael nygard template and reversibility analysis.

## When to use
- Task matches the skill scope as described above.
- The active persona is Enterprise / Solution Architect (or a peer persona delegating to this skill).

## How to apply
1. Confirm the inputs: SPECIFICATION.md or equivalent source-of-truth artifact.
2. Apply the persona's standard discipline to the task (see
   `.github/agents/enterprise-architect.agent.md`).
3. Produce a deliverable that is reviewable and reversible.
4. Cite the repo paths used.

## Quality gate
- [ ] Output is grounded in repo state, not invented.
- [ ] Reversibility documented.
- [ ] Persona constraints respected.

## References
- Companion playbook: `playbook.html` (sections specific to Enterprise / Solution Architect).
- Long-form analysis: `Agentic_DevOps_24_Personas_LongForm_v1_0_0_2026-04-07_en.html`.
