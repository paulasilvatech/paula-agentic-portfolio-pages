---
applyTo: "infrastructure/**,*.tf,*.bicep,*.yaml"
---

# Infrastructure conventions (Enterprise / Solution Architect)

IaC conventions: tagging, naming, region, secrets handling

## Reviewer checklist
- [ ] Naming follows project conventions.
- [ ] Error paths are explicit (no silent failures).
- [ ] Test coverage matches the change scope.
- [ ] No secrets or PII in code or comments.
- [ ] Reference `CONSTITUTION.md` for security-touching changes.
