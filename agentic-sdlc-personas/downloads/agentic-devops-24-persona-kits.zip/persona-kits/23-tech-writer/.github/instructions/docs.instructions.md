---
applyTo: "docs/**,README.md,CHANGELOG.md"
---

# Docs conventions (Tech Writer / Documentation Specialist)

Doc conventions: voice, terminology, audience, code samples, link checks

## Reviewer checklist
- [ ] Naming follows project conventions.
- [ ] Error paths are explicit (no silent failures).
- [ ] Test coverage matches the change scope.
- [ ] No secrets or PII in code or comments.
- [ ] Reference `CONSTITUTION.md` for security-touching changes.
