---
name: doc-drift-detection
description: "Detect doc drift by comparing API surface vs published docs Use when the Tech Writer / Documentation Specialist persona is active and the task matches the skill scope."
---

# Doc Drift Detection

This skill bundles the discipline a Tech Writer / Documentation Specialist brings when detect doc drift by comparing api surface vs published docs.

## When to use
- Task matches the skill scope as described above.
- The active persona is Tech Writer / Documentation Specialist (or a peer persona delegating to this skill).

## How to apply
1. Confirm the inputs: SPECIFICATION.md or equivalent source-of-truth artifact.
2. Apply the persona's standard discipline to the task (see
   `.github/agents/tech-writer.agent.md`).
3. Produce a deliverable that is reviewable and reversible.
4. Cite the repo paths used.

## Quality gate
- [ ] Output is grounded in repo state, not invented.
- [ ] Reversibility documented.
- [ ] Persona constraints respected.

## References
- Companion playbook: `playbook.html` (sections specific to Tech Writer / Documentation Specialist).
- Long-form analysis: `Agentic_DevOps_24_Personas_LongForm_v1_0_0_2026-04-07_en.html`.
