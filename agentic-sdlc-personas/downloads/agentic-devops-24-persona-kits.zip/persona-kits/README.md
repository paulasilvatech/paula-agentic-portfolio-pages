# 24 Persona Kits, Agentic DevOps SDLC

> Trilingual companion artifacts for the *Agentic DevOps SDLC, 24 Personas* deck.

This master archive bundles GitHub Copilot persona kits for every role in the
modern SDLC. Each kit is a standalone folder you can drop into a repository to
configure agent mode, custom instructions, slash commands, skills, MCP servers,
hooks, and a starter workflow per persona.

## Group 1 · Strategy and Discovery
01. Product Owner
02. Business Manager / Business Analyst
03. Requirements Engineer
04. Enterprise / Solution Architect
05. Software Architect
06. Technical Lead

## Group 2 · Build and Quality
07. Engineering Manager
08. UX / Product Designer
09. Scrum Master / Agile Coach
10. Project Manager
11. DevOps Engineer
12. Platform Architect
13. QA Engineer / Test Lead
14. UAT Analyst
15. Data Engineer
16. ML / AI Engineer

## Group 3 · Run and Reliability
17. Release Manager
18. InfoSec Officer
19. Compliance Auditor
20. SRE
21. DBA
22. Developer / Software Engineer

## Group 4 · Govern and Grow
23. Tech Writer
24. DevRel

## Quick start
```bash
# Pick the persona you need:
cd persona-kits/22-developer

# Read its README:
cat README.md

# Copy into your repo:
cp -r .github/* /path/to/your-repo/.github/
mkdir -p /path/to/your-repo/.vscode
cp mcp.json /path/to/your-repo/.vscode/mcp.json
```

## Per-kit structure
Every kit follows the canonical GitHub Copilot layout:

```
[NN]-{slug}/
├── README.md                              # usage guide for this persona
├── mcp.json                               # MCP servers (VS Code format)
├── .github/
│   ├── copilot-instructions.md            # repo-wide, persona-specific
│   ├── agents/{slug}.agent.md           # custom agent for the agent picker
│   ├── prompts/*.prompt.md                # slash commands (mode: ask|plan|agent)
│   ├── instructions/*.instructions.md     # scoped instructions (applyTo glob)
│   ├── skills/{skill}/SKILL.md          # agentskills.io skills
│   ├── workflows/*.yml                    # GitHub Actions
│   └── hooks/hooks.json                   # Claude Code lifecycle hooks
```

## Compliance
- Author: Paula Silva, Software Global Black Belt.
- Contact: paulasilva@microsoft.com.
- Built 2026-05-07.
- All kits validated for paulasilva-ms identity, no banned vocabulary, no em-dashes.

## Companion artifacts
- Deck: `Agentic_DevOps_SDLC_Personas_Deck_v3_0_0_2026-05-07_multi.html`
- Long-form: `Agentic_DevOps_24_Personas_LongForm_v1_0_0_2026-04-07_en.html`
- Playbook: `personas-ai-impact-sdlc/playbook.html`
- Astro site: `personas-ai-impact-sdlc/site/`
