---
name: tdd-loop
description: "TDD red-green-refactor loop with property-based test suggestions Use when the Developer / Software Engineer persona is active and the task matches the skill scope."
---

# Tdd Loop

This skill bundles the discipline a Developer / Software Engineer brings when tdd red-green-refactor loop with property-based test suggestions.

## When to use
- Task matches the skill scope as described above.
- The active persona is Developer / Software Engineer (or a peer persona delegating to this skill).

## How to apply
1. Confirm the inputs: SPECIFICATION.md or equivalent source-of-truth artifact.
2. Apply the persona's standard discipline to the task (see
   `.github/agents/developer.agent.md`).
3. Produce a deliverable that is reviewable and reversible.
4. Cite the repo paths used.

## Quality gate
- [ ] Output is grounded in repo state, not invented.
- [ ] Reversibility documented.
- [ ] Persona constraints respected.

## References
- Companion playbook: `playbook.html` (sections specific to Developer / Software Engineer).
- Long-form analysis: `Agentic_DevOps_24_Personas_LongForm_v1_0_0_2026-04-07_en.html`.
