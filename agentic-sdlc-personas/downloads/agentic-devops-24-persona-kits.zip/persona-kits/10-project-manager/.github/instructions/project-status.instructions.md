---
applyTo: "docs/status/**,docs/risks/**"
---

# Project Status conventions (Project Manager)

Status report format, RAG color rules, risk register schema

## Reviewer checklist
- [ ] Naming follows project conventions.
- [ ] Error paths are explicit (no silent failures).
- [ ] Test coverage matches the change scope.
- [ ] No secrets or PII in code or comments.
- [ ] Reference `CONSTITUTION.md` for security-touching changes.
