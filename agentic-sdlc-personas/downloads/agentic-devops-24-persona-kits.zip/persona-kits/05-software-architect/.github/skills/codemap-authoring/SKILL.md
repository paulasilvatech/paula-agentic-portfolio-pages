---
name: codemap-authoring
description: "CODEMAP.md generation and module decomposition Use when the Software Architect persona is active and the task matches the skill scope."
---

# Codemap Authoring

This skill bundles the discipline a Software Architect brings when codemap.md generation and module decomposition.

## When to use
- Task matches the skill scope as described above.
- The active persona is Software Architect (or a peer persona delegating to this skill).

## How to apply
1. Confirm the inputs: SPECIFICATION.md or equivalent source-of-truth artifact.
2. Apply the persona's standard discipline to the task (see
   `.github/agents/software-architect.agent.md`).
3. Produce a deliverable that is reviewable and reversible.
4. Cite the repo paths used.

## Quality gate
- [ ] Output is grounded in repo state, not invented.
- [ ] Reversibility documented.
- [ ] Persona constraints respected.

## References
- Companion playbook: `playbook.html` (sections specific to Software Architect).
- Long-form analysis: `Agentic_DevOps_24_Personas_LongForm_v1_0_0_2026-04-07_en.html`.
