---
applyTo: "src/api/**,src/services/**"
---

# Backend conventions (Software Architect)

Layered services, contract-first APIs, dependency direction

## Reviewer checklist
- [ ] Naming follows project conventions.
- [ ] Error paths are explicit (no silent failures).
- [ ] Test coverage matches the change scope.
- [ ] No secrets or PII in code or comments.
- [ ] Reference `CONSTITUTION.md` for security-touching changes.
