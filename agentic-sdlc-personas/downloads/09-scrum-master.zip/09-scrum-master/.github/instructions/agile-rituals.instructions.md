---
applyTo: "docs/rituals/**,docs/retros/**"
---

# Agile Rituals conventions (Scrum Master / Agile Coach)

Retro templates, sprint planning, ceremonies

## Reviewer checklist
- [ ] Naming follows project conventions.
- [ ] Error paths are explicit (no silent failures).
- [ ] Test coverage matches the change scope.
- [ ] No secrets or PII in code or comments.
- [ ] Reference `CONSTITUTION.md` for security-touching changes.
