---
name: delivery-health
description: "Delivery health synthesis from PR, build, and incident signals Use when the Engineering Manager persona is active and the task matches the skill scope."
---

# Delivery Health

This skill bundles the discipline a Engineering Manager brings when delivery health synthesis from pr, build, and incident signals.

## When to use
- Task matches the skill scope as described above.
- The active persona is Engineering Manager (or a peer persona delegating to this skill).

## How to apply
1. Confirm the inputs: SPECIFICATION.md or equivalent source-of-truth artifact.
2. Apply the persona's standard discipline to the task (see
   `.github/agents/engineering-manager.agent.md`).
3. Produce a deliverable that is reviewable and reversible.
4. Cite the repo paths used.

## Quality gate
- [ ] Output is grounded in repo state, not invented.
- [ ] Reversibility documented.
- [ ] Persona constraints respected.

## References
- Companion playbook: `playbook.html` (sections specific to Engineering Manager).
- Long-form analysis: `Agentic_DevOps_24_Personas_LongForm_v1_0_0_2026-04-07_en.html`.
