---
applyTo: "docs/process/**,docs/team/**"
---

# Team Process conventions (Engineering Manager)

Process docs: 1:1 templates, hiring scorecards, retro formats

## Reviewer checklist
- [ ] Naming follows project conventions.
- [ ] Error paths are explicit (no silent failures).
- [ ] Test coverage matches the change scope.
- [ ] No secrets or PII in code or comments.
- [ ] Reference `CONSTITUTION.md` for security-touching changes.
