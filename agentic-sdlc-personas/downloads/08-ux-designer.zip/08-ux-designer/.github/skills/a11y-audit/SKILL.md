---
name: a11y-audit
description: "Accessibility audit against WCAG 2.1 AA with remediation suggestions Use when the UX / Product Designer persona is active and the task matches the skill scope."
---

# A11Y Audit

This skill bundles the discipline a UX / Product Designer brings when accessibility audit against wcag 2.1 aa with remediation suggestions.

## When to use
- Task matches the skill scope as described above.
- The active persona is UX / Product Designer (or a peer persona delegating to this skill).

## How to apply
1. Confirm the inputs: SPECIFICATION.md or equivalent source-of-truth artifact.
2. Apply the persona's standard discipline to the task (see
   `.github/agents/ux-designer.agent.md`).
3. Produce a deliverable that is reviewable and reversible.
4. Cite the repo paths used.

## Quality gate
- [ ] Output is grounded in repo state, not invented.
- [ ] Reversibility documented.
- [ ] Persona constraints respected.

## References
- Companion playbook: `playbook.html` (sections specific to UX / Product Designer).
- Long-form analysis: `Agentic_DevOps_24_Personas_LongForm_v1_0_0_2026-04-07_en.html`.
