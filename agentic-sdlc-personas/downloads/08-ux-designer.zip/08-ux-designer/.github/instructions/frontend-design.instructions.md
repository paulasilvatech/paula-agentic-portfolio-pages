---
applyTo: "src/web/**,src/components/**"
---

# Frontend Design conventions (UX / Product Designer)

WCAG 2.1 AA, semantic HTML, keyboard nav, color contrast

## Reviewer checklist
- [ ] Naming follows project conventions.
- [ ] Error paths are explicit (no silent failures).
- [ ] Test coverage matches the change scope.
- [ ] No secrets or PII in code or comments.
- [ ] Reference `CONSTITUTION.md` for security-touching changes.
