---
name: release-risk
description: "Release risk assessment from PR, dependency, and deployment signals Use when the Release Manager / Change Manager persona is active and the task matches the skill scope."
---

# Release Risk

This skill bundles the discipline a Release Manager / Change Manager brings when release risk assessment from pr, dependency, and deployment signals.

## When to use
- Task matches the skill scope as described above.
- The active persona is Release Manager / Change Manager (or a peer persona delegating to this skill).

## How to apply
1. Confirm the inputs: SPECIFICATION.md or equivalent source-of-truth artifact.
2. Apply the persona's standard discipline to the task (see
   `.github/agents/release-manager.agent.md`).
3. Produce a deliverable that is reviewable and reversible.
4. Cite the repo paths used.

## Quality gate
- [ ] Output is grounded in repo state, not invented.
- [ ] Reversibility documented.
- [ ] Persona constraints respected.

## References
- Companion playbook: `playbook.html` (sections specific to Release Manager / Change Manager).
- Long-form analysis: `Agentic_DevOps_24_Personas_LongForm_v1_0_0_2026-04-07_en.html`.
