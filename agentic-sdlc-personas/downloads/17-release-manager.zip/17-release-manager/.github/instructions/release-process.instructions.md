---
applyTo: "CHANGELOG.md,docs/releases/**"
---

# Release Process conventions (Release Manager / Change Manager)

Release note format, semver, rollback drills

## Reviewer checklist
- [ ] Naming follows project conventions.
- [ ] Error paths are explicit (no silent failures).
- [ ] Test coverage matches the change scope.
- [ ] No secrets or PII in code or comments.
- [ ] Reference `CONSTITUTION.md` for security-touching changes.
