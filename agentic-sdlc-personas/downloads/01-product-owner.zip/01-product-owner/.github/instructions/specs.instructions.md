---
applyTo: "docs/specs/**,*.spec.md"
---

# Specs conventions (Product Owner)

Spec writing conventions: EARS notation, traceability, ambiguity flags

## Reviewer checklist
- [ ] Naming follows project conventions.
- [ ] Error paths are explicit (no silent failures).
- [ ] Test coverage matches the change scope.
- [ ] No secrets or PII in code or comments.
- [ ] Reference `CONSTITUTION.md` for security-touching changes.
