---
applyTo: "docs/kpis/**,docs/business/**"
---

# Kpi Docs conventions (Business Manager / Business Analyst)

KPI definition, baseline benchmarks, target setting

## Reviewer checklist
- [ ] Naming follows project conventions.
- [ ] Error paths are explicit (no silent failures).
- [ ] Test coverage matches the change scope.
- [ ] No secrets or PII in code or comments.
- [ ] Reference `CONSTITUTION.md` for security-touching changes.
