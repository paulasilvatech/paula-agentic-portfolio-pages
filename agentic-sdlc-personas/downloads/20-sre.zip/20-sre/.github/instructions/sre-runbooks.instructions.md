---
applyTo: "docs/runbooks/**,docs/postmortems/**"
---

# Sre Runbooks conventions (SRE / Site Reliability Engineer)

Runbook format: trigger, diagnosis steps, mitigation, rollback, postmortem

## Reviewer checklist
- [ ] Naming follows project conventions.
- [ ] Error paths are explicit (no silent failures).
- [ ] Test coverage matches the change scope.
- [ ] No secrets or PII in code or comments.
- [ ] Reference `CONSTITUTION.md` for security-touching changes.
