---
applyTo: "samples/**,examples/**,docs/tutorials/**"
---

# Samples conventions (DevRel / Developer Advocate)

Sample app conventions: minimal, runnable, single-purpose, README per sample

## Reviewer checklist
- [ ] Naming follows project conventions.
- [ ] Error paths are explicit (no silent failures).
- [ ] Test coverage matches the change scope.
- [ ] No secrets or PII in code or comments.
- [ ] Reference `CONSTITUTION.md` for security-touching changes.
