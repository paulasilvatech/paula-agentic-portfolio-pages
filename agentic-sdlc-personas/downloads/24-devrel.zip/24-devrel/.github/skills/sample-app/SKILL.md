---
name: sample-app
description: "Sample app scaffolding with one feature focus and clear teach-back Use when the DevRel / Developer Advocate persona is active and the task matches the skill scope."
---

# Sample App

This skill bundles the discipline a DevRel / Developer Advocate brings when sample app scaffolding with one feature focus and clear teach-back.

## When to use
- Task matches the skill scope as described above.
- The active persona is DevRel / Developer Advocate (or a peer persona delegating to this skill).

## How to apply
1. Confirm the inputs: SPECIFICATION.md or equivalent source-of-truth artifact.
2. Apply the persona's standard discipline to the task (see
   `.github/agents/devrel.agent.md`).
3. Produce a deliverable that is reviewable and reversible.
4. Cite the repo paths used.

## Quality gate
- [ ] Output is grounded in repo state, not invented.
- [ ] Reversibility documented.
- [ ] Persona constraints respected.

## References
- Companion playbook: `playbook.html` (sections specific to DevRel / Developer Advocate).
- Long-form analysis: `Agentic_DevOps_24_Personas_LongForm_v1_0_0_2026-04-07_en.html`.
