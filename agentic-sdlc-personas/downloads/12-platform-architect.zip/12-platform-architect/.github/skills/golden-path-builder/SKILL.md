---
name: golden-path-builder
description: "Golden path scaffolding and developer onboarding template Use when the DevOps / Platform Architect persona is active and the task matches the skill scope."
---

# Golden Path Builder

This skill bundles the discipline a DevOps / Platform Architect brings when golden path scaffolding and developer onboarding template.

## When to use
- Task matches the skill scope as described above.
- The active persona is DevOps / Platform Architect (or a peer persona delegating to this skill).

## How to apply
1. Confirm the inputs: SPECIFICATION.md or equivalent source-of-truth artifact.
2. Apply the persona's standard discipline to the task (see
   `.github/agents/platform-architect.agent.md`).
3. Produce a deliverable that is reviewable and reversible.
4. Cite the repo paths used.

## Quality gate
- [ ] Output is grounded in repo state, not invented.
- [ ] Reversibility documented.
- [ ] Persona constraints respected.

## References
- Companion playbook: `playbook.html` (sections specific to DevOps / Platform Architect).
- Long-form analysis: `Agentic_DevOps_24_Personas_LongForm_v1_0_0_2026-04-07_en.html`.
