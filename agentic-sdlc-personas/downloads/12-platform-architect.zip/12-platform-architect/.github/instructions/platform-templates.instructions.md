---
applyTo: "templates/**,scaffolder/**"
---

# Platform Templates conventions (DevOps / Platform Architect)

Backstage template conventions and parameter schemas

## Reviewer checklist
- [ ] Naming follows project conventions.
- [ ] Error paths are explicit (no silent failures).
- [ ] Test coverage matches the change scope.
- [ ] No secrets or PII in code or comments.
- [ ] Reference `CONSTITUTION.md` for security-touching changes.
