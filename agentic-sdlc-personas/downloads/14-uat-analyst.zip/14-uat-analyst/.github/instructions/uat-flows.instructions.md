---
applyTo: "tests/uat/**,docs/user-flows/**"
---

# Uat Flows conventions (UAT Analyst)

UAT scenario format, traceability to AC

## Reviewer checklist
- [ ] Naming follows project conventions.
- [ ] Error paths are explicit (no silent failures).
- [ ] Test coverage matches the change scope.
- [ ] No secrets or PII in code or comments.
- [ ] Reference `CONSTITUTION.md` for security-touching changes.
