---
applyTo: "src/auth/**,src/crypto/**,**/secrets/**"
---

# Security Review conventions (InfoSec / Compliance Officer)

Security review checklist: OWASP top 10, supply chain, secrets handling

## Reviewer checklist
- [ ] Naming follows project conventions.
- [ ] Error paths are explicit (no silent failures).
- [ ] Test coverage matches the change scope.
- [ ] No secrets or PII in code or comments.
- [ ] Reference `CONSTITUTION.md` for security-touching changes.
