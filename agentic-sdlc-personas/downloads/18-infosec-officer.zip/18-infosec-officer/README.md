# 18 · InfoSec / Compliance Officer, Persona kit

> Threat modeling, policy as code, vulnerability triage (READ-ONLY)

This kit packages everything a InfoSec / Compliance Officer needs to operate in a repository
that uses GitHub Copilot agent mode and the Spec-Driven Development workflow:
custom instructions, scoped instructions, slash commands, a custom agent,
reusable skills, MCP server hints, GitHub Actions workflow, and Claude Code
hooks.

## Contents

### Repo-wide instructions
- `.github/copilot-instructions.md`, loaded automatically by GitHub Copilot for
  every chat session on this repo. Defines persona role, conventions, allowed
  and restricted actions for the InfoSec / Compliance Officer.

### Custom agent
- `.github/agents/infosec-officer.agent.md`, selectable from the agent picker
  in GitHub Copilot Chat (Visual Studio 2026 18.4+ or VS Code with agent mode).

### Slash commands (prompts)
- `/review-control` (mode: `ask`), Review a control or policy: check coverage, evidence trail, gaps, drift
- `/draft-evidence` (mode: `agent`), Draft evidence document for a control: scope, evidence sources, gap analysis
- `/plan-audit` (mode: `plan`), Plan an audit cycle: scope, control set, evidence collection, reporting

Each prompt sets `mode: ask | plan | agent` in frontmatter, the only three
chat modes used in current GitHub Copilot. Invoke from the chat input by typing
`/` followed by the prompt name.

### Scoped instructions
- `.github/instructions/security-review.instructions.md` (applyTo: `src/auth/**,src/crypto/**,**/secrets/**`)

These attach automatically when files matching the `applyTo` glob are in
context.

### Skills (agentskills.io)
- `.github/skills/threat-modeling/SKILL.md`, STRIDE threat modeling per service with mitigation mapping

Place each skill folder under `.github/skills/` so GitHub Copilot can discover
it. Skills are lazy-loaded: install many, pay only for those activated by
context.

### MCP servers
- `github-advanced-security`, CodeQL, secret scanning, dependency review
- `microsoft-defender`, Cloud security posture

The `mcp.json` shipped here uses the `servers` key (GitHub Copilot Visual Studio
and VS Code format). For Visual Studio, place at the solution root or
`%USERPROFILE%\.mcp.json`. For VS Code, place at `.vscode/mcp.json`.

### GitHub Actions workflow
- `.github/workflows/sec-review.yml`, Security review on auth or crypto PR.
  Customize the validation step to your repo before enabling.

### Hooks
- `.github/hooks/hooks.json`, Claude Code lifecycle hooks. PreToolUse and
  PostToolUse stubs you can extend per repo policy. Move to `.claude/hooks.json`
  if you use Claude Code.

## Installation

```bash
# 1. Copy .github content into your repo (skip directories you do not want)
cp -r .github/* /path/to/your-repo/.github/

# 2. Place mcp.json (VS Code: .vscode/, Visual Studio: solution root)
mkdir -p /path/to/your-repo/.vscode
cp mcp.json /path/to/your-repo/.vscode/mcp.json

# 3. Enable custom instructions in your IDE
#    Visual Studio: Tools > Options > GitHub > Copilot > Copilot Chat > Enable custom instructions
#    VS Code: settings.json -> "github.copilot.chat.codeGeneration.useInstructionFiles": true

# 4. Restart the IDE so Copilot picks up the new agent and prompts
```

## Verifying installation

In GitHub Copilot Chat:
- Type `/` and confirm the persona's slash commands appear.
- Open the agent picker and confirm the persona agent is listed.
- Open a file matching one of the `applyTo` globs and confirm the scoped
  instructions appear in the References list of a Copilot response.
- Open the Tools menu and confirm the recommended MCP servers are listed once
  configured in `mcp.json`.

## Best practices (research-backed)

- AGENTS.md must be human-curated (arXiv:2601.20404 reports LLM-generated agent
  files reduce success by roughly 3 percent).
- `applyTo` scoping reduces tokens by about 68 percent versus loading global
  instructions on every request.
- Skills are lazy-loaded: install many, pay for the few that activate.
- Hooks cost zero LLM tokens, making them the cheapest governance layer.
- Extended thinking can harm iterative tasks by 30 percent quality
  (arXiv:2505.01622). Use when the task is genuinely multi-step.
- Rich natural-language instructions outperform terse abbreviations
  (arXiv:2604.07502).

## References
- [GitHub Copilot custom instructions](https://learn.microsoft.com/visualstudio/ide/copilot-chat-context)
- [GitHub Copilot custom agents](https://learn.microsoft.com/visualstudio/ide/copilot-specialized-agents)
- [GitHub Copilot agent skills](https://learn.microsoft.com/visualstudio/ide/copilot-agent-skills)
- [MCP servers for GitHub Copilot](https://learn.microsoft.com/visualstudio/ide/mcp-servers)
- [Spec-Kit](https://github.com/github/spec-kit)
- [agentskills.io specification](https://agentskills.io/specification)

## Identity and contact
Author: Paula Silva, Software Global Black Belt.
Contact: paulasilva@microsoft.com.

Companion documents:
- Deck (trilingual): `Agentic_DevOps_SDLC_Personas_Deck_v3_0_0_2026-05-07_multi.html`
- Long-form analysis (EN): `Agentic_DevOps_24_Personas_LongForm_v1_0_0_2026-04-07_en.html`
- Playbook: `playbook.html`
- Site (this Astro app): `personas-ai-impact-sdlc/site/`
